package com.aryan.stumps11.CreateTeam;

public interface PointsCallback {
    public void onPointsUpdate();
}
