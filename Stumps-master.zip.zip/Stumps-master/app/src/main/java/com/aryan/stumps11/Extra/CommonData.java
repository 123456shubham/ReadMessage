package com.aryan.stumps11.Extra;

public class CommonData {

    public static String Match_id="MATCHID";
    public static String C_I_D="CID";
    public static String TEAM_ID="team_id";
    public  static String CREDIT_POINT="creditPoint";
    public static String playerName="PlayerName";



}
