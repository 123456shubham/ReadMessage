package com.aryan.stumps11.ApiModel.profile.DummyTeamResponse;

public class MyTeamDummyModel {
    private String cName;
    private String vcName;
    private  String teamID;
    private String userId;
    private String cid;
    private String totalWk;
    private String totalAR;
    private String totalBat;
    private String totalBwl;

    public String getTotalWk() {
        return totalWk;
    }

    public void setTotalWk(String totalWk) {
        this.totalWk = totalWk;
    }

    public String getTotalAR() {
        return totalAR;
    }

    public void setTotalAR(String totalAR) {
        this.totalAR = totalAR;
    }

    public String getTotalBat() {
        return totalBat;
    }

    public void setTotalBat(String totalBat) {
        this.totalBat = totalBat;
    }

    public String getTotalBwl() {
        return totalBwl;
    }

    public void setTotalBwl(String totalBwl) {
        this.totalBwl = totalBwl;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public MyTeamDummyModel() {
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getVcName() {
        return vcName;
    }

    public void setVcName(String vcName) {
        this.vcName = vcName;
    }

    public String getTeamID() {
        return teamID;
    }

    public void setTeamID(String teamID) {
        this.teamID = teamID;
    }
}
