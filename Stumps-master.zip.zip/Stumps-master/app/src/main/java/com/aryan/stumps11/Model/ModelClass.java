package com.aryan.stumps11.Model;

public class ModelClass {

    //For Winners
    String Winneramount,WinnerUsername,WinnerState;
    //For Transaction
    String Tamt,tid,tdate;
    //For HomePage
    String sname,tname1,tname2,timage1,timage2,matchid;
    //For My Matches
    String smname,tmname1,tmname2,status;
    int tmimage1,tmimage2;
    //For Slider
    String images;
    //For Contest
    String maxteams,bonus,prizepool,entry,joined,spotstotal,contesttype,winpercentage;
    //For CreateTeam
    String Tname,pname,pstatus,id,pts,credits,role,country,points;
    //For Team on Green Background
    String playername,pcredit,Cap,vc;
    //For JoinedContest
    String maxteams1,bonus1,prizepool1,entry1,joined1,spotstotal1,contesttype1,winpercentage1;
    // for comming up match timing
    String matchTiming;
    String cid;


    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getMatchTiming() {
        return matchTiming;
    }

    public void setMatchTiming(String matchTiming) {
        this.matchTiming = matchTiming;
    }

    public String getMaxteams1() {
        return maxteams1;
    }

    public void setMaxteams1(String maxteams1) {
        this.maxteams1 = maxteams1;
    }

    public String getBonus1() {
        return bonus1;
    }

    public void setBonus1(String bonus1) {
        this.bonus1 = bonus1;
    }

    public String getPrizepool1() {
        return prizepool1;
    }

    public void setPrizepool1(String prizepool1) {
        this.prizepool1 = prizepool1;
    }

    public String getEntry1() {
        return entry1;
    }

    public void setEntry1(String entry1) {
        this.entry1 = entry1;
    }

    public String getJoined1() {
        return joined1;
    }

    public void setJoined1(String joined1) {
        this.joined1 = joined1;
    }

    public String getSpotstotal1() {
        return spotstotal1;
    }

    public void setSpotstotal1(String spotstotal1) {
        this.spotstotal1 = spotstotal1;
    }

    public String getContesttype1() {
        return contesttype1;
    }

    public void setContesttype1(String contesttype1) {
        this.contesttype1 = contesttype1;
    }

    public String getWinpercentage1() {
        return winpercentage1;
    }

    public void setWinpercentage1(String winpercentage1) {
        this.winpercentage1 = winpercentage1;
    }

    public String getMatchid() {
        return matchid;
    }

    public void setMatchid(String matchid) {
        this.matchid = matchid;
    }

    public String getVc() {
        return vc;
    }

    public void setVc(String vc) {
        this.vc = vc;
    }

    //For CVC
    String Teamname1,pname1,pts1,role1;

    public String getCap() {
        return Cap;
    }

    public void setCap(String cap) {
        Cap = cap;
    }

    public String getTeamname1() {
        return Teamname1;
    }

    public void setTeamname1(String teamname1) {
        Teamname1 = teamname1;
    }

    public String getPname1() {
        return pname1;
    }

    public void setPname1(String pname1) {
        this.pname1 = pname1;
    }

    public String getPts1() {
        return pts1;
    }

    public void setPts1(String pts1) {
        this.pts1 = pts1;
    }

    public String getRole1() {
        return role1;
    }

    public void setRole1(String role1) {
        this.role1 = role1;
    }

    public String getPcredit() {
        return pcredit;
    }

    public void setPcredit(String pcredit) {
        this.pcredit = pcredit;
    }

    public String getPlayername() {
        return playername;
    }

    public void setPlayername(String playername) {
        this.playername = playername;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }


    public String getPstatus() {
        return pstatus;
    }

    public void setPstatus(String pstatus) {
        this.pstatus = pstatus;
    }

    public String getTname() {
        return Tname;
    }

    public void setTname(String tname) {
        Tname = tname;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPts() {
        return pts;
    }

    public void setPts(String pts) {
        this.pts = pts;
    }

    public String getCredits() {
        return credits;
    }

    public void setCredits(String credits) {
        this.credits = credits;
    }

    public String getContesttype() {
        return contesttype;
    }

    public void setContesttype(String contesttype) {
        this.contesttype = contesttype;
    }

    public String getWinpercentage() {
        return winpercentage;
    }

    public void setWinpercentage(String winpercentage) {
        this.winpercentage = winpercentage;
    }

    public String getMaxteams() {
        return maxteams;
    }

    public void setMaxteams(String maxteams) {
        this.maxteams = maxteams;
    }

    public String getBonus() {
        return bonus;
    }

    public void setBonus(String bonus) {
        this.bonus = bonus;
    }

    public String getPrizepool() {
        return prizepool;
    }

    public void setPrizepool(String prizepool) {
        this.prizepool = prizepool;
    }

    public String getEntry() {
        return entry;
    }

    public void setEntry(String entry) {
        this.entry = entry;
    }

    public String getJoined() {
        return joined;
    }

    public void setJoined(String joined) {
        this.joined = joined;
    }

    public String getSpotstotal() {
        return spotstotal;
    }

    public void setSpotstotal(String spotstotal) {
        this.spotstotal = spotstotal;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSmname() {
        return smname;
    }

    public void setSmname(String smname) {
        this.smname = smname;
    }

    public String getTmname1() {
        return tmname1;
    }

    public void setTmname1(String tmname1) {
        this.tmname1 = tmname1;
    }

    public String getTmname2() {
        return tmname2;
    }

    public void setTmname2(String tmname2) {
        this.tmname2 = tmname2;
    }

    public int getTmimage1() {
        return tmimage1;
    }

    public void setTmimage1(int tmimage1) {
        this.tmimage1 = tmimage1;
    }

    public int getTmimage2() {
        return tmimage2;
    }

    public void setTmimage2(int tmimage2) {
        this.tmimage2 = tmimage2;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getTname1() {
        return tname1;
    }

    public void setTname1(String tname1) {
        this.tname1 = tname1;
    }

    public String getTname2() {
        return tname2;
    }

    public void setTname2(String tname2) {
        this.tname2 = tname2;
    }

    public String getTimage1() {
        return timage1;
    }

    public void setTimage1(String timage1) {
        this.timage1 = timage1;
    }

    public String getTimage2() {
        return timage2;
    }

    public void setTimage2(String timage2) {
        this.timage2 = timage2;
    }

    public String getTamt() {
        return Tamt;
    }

    public void setTamt(String tamt) {
        Tamt = tamt;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getTdate() {
        return tdate;
    }

    public void setTdate(String tdate) {
        this.tdate = tdate;
    }

    public String getWinneramount() {
        return Winneramount;
    }

    public void setWinneramount(String winneramount) {
        Winneramount = winneramount;
    }

    public String getWinnerUsername() {
        return WinnerUsername;
    }

    public void setWinnerUsername(String winnerUsername) {
        WinnerUsername = winnerUsername;
    }

    public String getWinnerState() {
        return WinnerState;
    }

    public void setWinnerState(String winnerState) {
        WinnerState = winnerState;
    }
}
