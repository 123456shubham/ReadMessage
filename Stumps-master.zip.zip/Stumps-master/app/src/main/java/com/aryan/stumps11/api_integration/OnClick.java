package com.aryan.stumps11.api_integration;

public interface OnClick {
    public void onClick();
}
