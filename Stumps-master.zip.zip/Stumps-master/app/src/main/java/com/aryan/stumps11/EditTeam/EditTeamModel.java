package com.aryan.stumps11.EditTeam;

public class EditTeamModel {
    private String editPlayerId;
    private String editPlayerStatus;
    private String editPlayerCreditPoint;
    private String editPlayerCountryName;
    private String editTeamName;
    private String editPlayerRole;
    private String editPlayerName;
    private String editPoints;
    private boolean isCheck;
    private int wk;
    private int bat;
    private int ar;
    private int bwl;

    public int getWk() {
        return wk;
    }

    public void setWk(int wk) {
        this.wk = wk;
    }

    public int getBat() {
        return bat;
    }

    public void setBat(int bat) {
        this.bat = bat;
    }

    public int getAr() {
        return ar;
    }

    public void setAr(int ar) {
        this.ar = ar;
    }

    public int getBwl() {
        return bwl;
    }

    public void setBwl(int bwl) {
        this.bwl = bwl;
    }

    public boolean isCheck() {
        return isCheck;
    }

    public void setCheck(boolean check) {
        isCheck = check;
    }

    public String getEditPoints() {
        return editPoints;
    }

    public void setEditPoints(String editPoints) {
        this.editPoints = editPoints;
    }

    public String getEditPlayerName() {
        return editPlayerName;
    }

    public void setEditPlayerName(String editPlayerName) {
        this.editPlayerName = editPlayerName;
    }

    public String getEditTeamName() {
        return editTeamName;
    }

    public void setEditTeamName(String editTeamName) {
        this.editTeamName = editTeamName;
    }

    public String getEditPlayerRole() {
        return editPlayerRole;
    }

    public void setEditPlayerRole(String editPlayerRole) {
        this.editPlayerRole = editPlayerRole;
    }

    public String getEditPlayerCountryName() {
        return editPlayerCountryName;
    }

    public void setEditPlayerCountryName(String editPlayerCountryName) {
        this.editPlayerCountryName = editPlayerCountryName;
    }

    public String getEditPlayerId() {
        return editPlayerId;
    }

    public void setEditPlayerId(String editPlayerId) {
        this.editPlayerId = editPlayerId;
    }

    public String getEditPlayerStatus() {
        return editPlayerStatus;
    }

    public void setEditPlayerStatus(String editPlayerStatus) {
        this.editPlayerStatus = editPlayerStatus;
    }

    public String getEditPlayerCreditPoint() {
        return editPlayerCreditPoint;
    }

    public void setEditPlayerCreditPoint(String editPlayerCreditPoint) {
        this.editPlayerCreditPoint = editPlayerCreditPoint;
    }
}
