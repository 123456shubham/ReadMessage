package com.aryan.stumps11.dataPassing;

import java.util.ArrayList;

public interface DataPassringInterface {
    public  void sendData(String data);
}
