package com.aryan.stumps11.ApiModel.profile.profilegetProfile;

public class ProfileRequest {
}
