package com.loanshala.loan_shala.Others;

public class Constants {
    public static final String IS_LOGIN = "isLoggedIn";
    public static final String API_URL = "https://chintamani.arramton.co.in/api/";

    //SharedPrefs
    public static final String USERDATA = "user_data";
}
