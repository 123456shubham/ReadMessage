package com.loanshala.loan_shala.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.loanshala.loan_shala.R;

public class AboutFragment extends Fragment {
    View view;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_about, container, false);
        getActivity().setTitle("About");
        String app_version = "";
        try {
            app_version = getContext().getPackageManager().getPackageInfo("com.loanshala.loan_shala", 0).versionName;
        } catch (Exception e) {
            e.printStackTrace();
        }

        TextView txt_app_version = view.findViewById(R.id.app_version);
        txt_app_version.setText("Version " + app_version);
        return view;
    }
}