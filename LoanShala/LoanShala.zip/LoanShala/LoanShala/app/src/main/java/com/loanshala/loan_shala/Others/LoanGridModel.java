package com.loanshala.loan_shala.Others;

public class LoanGridModel {
    private String loan_type;
    private String loan_type_id;
    private int type_img_id;
    public LoanGridModel(String loan_type,int type_img_id,String loan_type_id){
        this.loan_type=loan_type;
        this.type_img_id=type_img_id;
        this.loan_type_id=loan_type_id;
    }

    public String getLoanType(){
        return loan_type;
    }
    public String getLoanTypeId(){
        return loan_type_id;
    }
    public int getTypeImgId(){
        return type_img_id;
    }
}
