package com.loanshala.loan_shala.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import com.loanshala.loan_shala.Others.Constants;
import com.loanshala.loan_shala.R;

public class LauncherScreenActivity extends AppCompatActivity {
Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher_screen);
        handler=new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                SharedPreferences prefs = getSharedPreferences(Constants.USERDATA, Context.MODE_PRIVATE);
                boolean is_login=prefs.getBoolean(Constants.IS_LOGIN, false);
                if (is_login) {
                    Intent i = new Intent(LauncherScreenActivity.this, DashboardActivity.class);
                    startActivity(i);
                    finish();
                } else {
                    Intent i = new Intent(LauncherScreenActivity.this, LoginActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        }, 500);
    }
}