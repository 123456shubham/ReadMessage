package com.loanshala.loan_shala.Fragments;

import static android.content.Context.MODE_PRIVATE;
import static com.loanshala.loan_shala.Others.Constants.API_URL;
import static com.loanshala.loan_shala.Others.Constants.USERDATA;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.loanshala.loan_shala.Activity.DashboardActivity;
import com.loanshala.loan_shala.Activity.LauncherScreenActivity;
import com.loanshala.loan_shala.Others.Constants;
import com.loanshala.loan_shala.Others.CustomDialog;
import com.loanshala.loan_shala.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class PersonalDetailFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    View view;
    TextView txt_dob, file_chooser_profile;
    String time_format, loan_type = "", loan_amount = "", dob = "", staying_year = "", local_address = "", city = "", profileHash = "";
    String loan_name = "", pin = "", spouse_name = "", spouse_phone = "", current_loan = "", current_loan_emi = "";
    Spinner spinner_house_type, spinner_state_type, spinner_spouse_occupation;
    Button btn_cancle, btn_save;
    RadioGroup gender_radio_group, marital_radio_group;
    RadioButton radiobutton;
    int index = 0, marital_status, spouse_occupation, gender, house_type, state;
    EditText home_et_spouse_name, home_et_curent_loan_amount, home_et_curent_loan_emi, home_et_spouse_phone, home_et_local_add, home_et_pincode, home_et_city, home_et_staying_years;
    HashMap<String, String> base64Hash;
    private static final int SELECT_FILE = 2;
    private static final int MY_REQUEST_CODE_PERMISSION = 1000;
    CustomDialog customDialog;
    LinearLayout upload_profile_layout;
    HashMap<String, Integer> state_code_hash, house_type_hash, spouse_occupation_hash;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_personal_detail, container, false);

        Bundle bundle = this.getArguments();
        if (bundle != null) {
            loan_type = bundle.getString("loan_id");
            loan_name = bundle.getString("loan_name");
            getActivity().setTitle(loan_name);
        }

        home_et_staying_years = view.findViewById(R.id.home_et_staying_years);
        gender_radio_group = view.findViewById(R.id.gender_radio_group);
        txt_dob = view.findViewById(R.id.pers_txt_dob);
        file_chooser_profile = view.findViewById(R.id.chooser_profile);
        upload_profile_layout = view.findViewById(R.id.profile_layout);
        spinner_house_type = view.findViewById(R.id.spinner_house_type);
        home_et_local_add = view.findViewById(R.id.home_et_local_add);
        home_et_city = view.findViewById(R.id.home_et_city);
        spinner_state_type = view.findViewById(R.id.spinner_state_type);
        home_et_pincode = view.findViewById(R.id.home_et_pincode);
        marital_radio_group = view.findViewById(R.id.marital_radio_group);
        home_et_spouse_name = view.findViewById(R.id.home_et_spouse_name);
        home_et_spouse_phone = view.findViewById(R.id.home_et_spouse_phone);
        spinner_spouse_occupation = view.findViewById(R.id.spinner_spouse_occupation);
        home_et_curent_loan_amount = view.findViewById(R.id.home_et_curent_loan_amount);
        home_et_curent_loan_emi = view.findViewById(R.id.home_et_curent_loan_emi);
        btn_cancle = view.findViewById(R.id.personal_btn_cancle);
        btn_save = view.findViewById(R.id.personal_btn_save);

        spinner_house_type.setOnItemSelectedListener(this);
        spinner_state_type.setOnItemSelectedListener(this);
        spinner_spouse_occupation.setOnItemSelectedListener(this);
        txt_dob.setOnClickListener(this);
        btn_cancle.setOnClickListener(this);
        btn_save.setOnClickListener(this);
        upload_profile_layout.setOnClickListener(this);

        state_code_hash = new HashMap<>();
        house_type_hash = new HashMap<>();
        spouse_occupation_hash = new HashMap<>();

        customDialog = new CustomDialog(getActivity());

        gender_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                radiobutton = (RadioButton) group.findViewById(checkedId);
                if (checkedId != 0) {
                    String selected = (String) radiobutton.getText();
                    if (selected.equals("Male")) {
                        gender = 1;
                    } else if (selected.equals("Female")) {
                        gender = 2;
                    } else {
                        gender = 3;
                    }
                }
            }
        });
        marital_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                radiobutton = (RadioButton) group.findViewById(checkedId);
                if (checkedId != 0) {
                    String selected = (String) radiobutton.getText();
                    if (selected.equals("Married")) {
                        marital_status = 1;
                    } else {
                        marital_status = 0;
                    }
                }
            }
        });

        //Get Dropdown values
        getStateList();

        return view;
    }

    public void date(final TextView textView) {
        final int mYear, mMonth, mDay;
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        time_format = dateFormat.format(c.getInstance().getTime());
        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), R.style.MyDatePickerDialogTheme,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        monthOfYear += 1;
                        String month, day;   //local variable
                        if (monthOfYear < 10) {
                            month = "0" + monthOfYear;
                        }//if month less than 10 then add 0 before month
                        else {
                            month = String.valueOf(monthOfYear);
                        }
                        if (dayOfMonth < 10) {
                            day = "0" + dayOfMonth;
                        }//if day less than 10 then add 0 before day
                        else {
                            day = String.valueOf(dayOfMonth);
                        }
                        String date = day + "-" + month + "-" + year;
                        textView.setText(date);
                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    @Override
    public void onClick(View v) {
        try {
            switch (v.getId()) {
                case R.id.pers_txt_dob:
                    date(txt_dob);
                    break;
                case R.id.profile_layout:
                    askPermission();
                    break;
                case R.id.personal_btn_save:
                    loan_amount = home_et_curent_loan_amount.getText().toString();
                    if (loan_amount.equals("") || loan_amount.equals("0")) {
                        home_et_curent_loan_amount.requestFocus();
                        home_et_curent_loan_amount.setError("Please Enter amount");
                    } else {
                        dob = txt_dob.getText().toString();
                        staying_year = home_et_staying_years.getText().toString();
                        local_address = home_et_local_add.getText().toString();
                        city = home_et_city.getText().toString();
                        pin = home_et_pincode.getText().toString();
                        spouse_name = home_et_spouse_name.getText().toString();
                        spouse_phone = home_et_spouse_phone.getText().toString();
                        current_loan = home_et_curent_loan_amount.getText().toString();
                        current_loan_emi = home_et_curent_loan_emi.getText().toString();
                        state = state_code_hash.get(spinner_state_type.getSelectedItem().toString());
                        house_type = house_type_hash.get(spinner_house_type.getSelectedItem().toString());
                        spouse_occupation = spouse_occupation_hash.get(spinner_spouse_occupation.getSelectedItem().toString());

                        JSONObject params = new JSONObject();
                        try {
                            params.put("loan_type", loan_type);
                            params.put("loan_amount", loan_amount);
                            if (gender >= 0) {
                                params.put("gender", gender);
                            }
                            if (!dob.equals("")) {
                                params.put("dob", dob);
                            }
                            if (house_type > 0) {
                                params.put("house_type", house_type);
                            }
                            if (!staying_year.equals("")) {
                                params.put("staying_year", staying_year);
                            }
                            if (!local_address.equals("")) {
                                params.put("local_address", local_address);
                            }
                            if (state > 0) {
                                params.put("state", state);
                            }
                            if (!city.equals("")) {
                                params.put("city", city);
                            }
                            if (!pin.equals("")) {
                                params.put("pin", pin);
                            }
                            if (marital_status >= 0) {
                                params.put("marital_status", marital_status);
                            }
                            if (!spouse_name.equals("")) {
                                params.put("spouse_name", spouse_name);
                            }
                            if (!spouse_phone.equals("")) {
                                params.put("spouse_phone", spouse_phone);
                            }
                            if (spouse_occupation > 0) {
                                params.put("spouse_occupation", spouse_occupation);
                            }
                            if (!current_loan.equals("")) {
                                params.put("current_loan", current_loan);
                            }
                            if (!current_loan_emi.equals("")) {
                                params.put("current_loan_emi", current_loan_emi);
                            }
                            if (!profileHash.equals("")) {
                                params.put("image", "data:image/jpeg;base64," + profileHash);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        UploadFormApi(params);
                    }
                    break;
                case R.id.personal_btn_cancle:
                    Intent i = new Intent(getContext(), DashboardActivity.class);
                    startActivity(i);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            showSnackbar("Some Internal Error Occurred");
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void askPermission() {
        // With Android Level >= 23, you have to ask the user
        // for permission to access External Storage.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) { // Level 23

            // Check if we have Call permission
            int permisson = ActivityCompat.checkSelfPermission(getContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE);

            if (permisson != PackageManager.PERMISSION_GRANTED) {
                // If don't have permission so prompt the user.
                this.requestPermissions(
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_REQUEST_CODE_PERMISSION
                );
                return;
            }
        }
        openGallery();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //
        if (requestCode == MY_REQUEST_CODE_PERMISSION) {// Note: If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            }
            // Cancelled or denied.
            else {
                showSnackbar("Permission Denied");
            }
        }
    }

    private void openGallery() {
        Intent chooseFileIntent = new Intent(Intent.ACTION_PICK);
        chooseFileIntent.setType("image/*");
        // Only return URIs that can be opened with ContentResolver
        chooseFileIntent = Intent.createChooser(chooseFileIntent, "Choose a file");
        startActivityForResult(chooseFileIntent, SELECT_FILE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == getActivity().RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                System.out.println("SELECT_FILE");
                Uri selectedImageUri = data.getData();
                getPath(selectedImageUri);
            }
        }
    }

    public void getPath(Uri uri) {
        try {
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContext().getContentResolver().query(uri, projection, null, null, null);
            if (cursor.getCount() > 0) {
                if (cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndex(projection[0]);
                    String filepath = cursor.getString(columnIndex);
                    Uri url = Uri.parse(filepath);
                    File file = new File(url.getPath());

                    float length = file.length();
                    if (length >= 50000000) {
                        showSnackbar("Media too long. Max allowed size : 5MB");
                    } else {
                        byte[] ByteArray = new byte[(int) file.length()];
                        try {
                            FileInputStream fileInputStream = new FileInputStream(file);
                            fileInputStream.read(ByteArray);
                            byte[] encodeFile = Base64.encode(ByteArray, 0);
                            profileHash = new String(encodeFile);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        String filename = file.getName();
                        file_chooser_profile.setText(filename);
                        showSnackbar("Selected File : " + filename);
                    }
                }
                cursor.close();
            } else {
                showSnackbar("No file selected");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showSnackbar("Something went wrong");
        }
    }

    private void getStateList() {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            String URL = API_URL + "states";

            StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    processStateList(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    customDialog.stopLoading();
                    showSnackbar("Some Error Occurred");
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }
            };
            int socketTimeout = 90000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something went wrong.");
        }
    }

    private void processStateList(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            String status = jsonObject.getString("status");
            ArrayList<String> spinner = new ArrayList<String>();
            spinner.add("--Select State--");
            state_code_hash.put("--Select State--", 0);
            if (status.equals("200")) {
                JSONArray list = jsonObject.getJSONArray("list");
                int len = list.length();
                for (int i = 0; i < len; i++) {
                    JSONObject objects = list.getJSONObject(i);
                    String state_id = objects.getString("StateID");
                    String state_name = objects.getString("StateName");
                    state_code_hash.put(state_name, Integer.parseInt(state_id));
                    spinner.add(state_name);
                }
                ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, spinner);
                spinner_state_type.setAdapter(spinnerAdapter);
            } else {
                showSnackbar("Error");
            }
            customDialog.stopLoading();
            getOccupationList();
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something bad happened");
        }
    }

    private void getOccupationList() {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            String URL = API_URL + "occupations";

            StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    processOccupationList(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    customDialog.stopLoading();
                    showSnackbar("Some Error Occurred");
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }
            };
            int socketTimeout = 90000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something went wrong.");
        }
    }

    private void processOccupationList(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            String status = jsonObject.getString("status");
            ArrayList<String> spinner = new ArrayList<String>();
            spinner.add("--Select Occupation--");
            spouse_occupation_hash.put("--Select Occupation--", 0);
            if (status.equals("200")) {
                JSONArray list = jsonObject.getJSONArray("list");
                int len = list.length();
                for (int i = 0; i < len; i++) {
                    JSONObject objects = list.getJSONObject(i);
                    String id = objects.getString("id");
                    String name = objects.getString("title");
                    spouse_occupation_hash.put(name, Integer.parseInt(id));
                    spinner.add(name);
                }
                ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, spinner);
                spinner_spouse_occupation.setAdapter(spinnerAdapter);
            } else {
                showSnackbar("Error");
            }
            customDialog.stopLoading();
            getHouseList();
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something bad happened");
        }
    }

    private void getHouseList() {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            String URL = API_URL + "house-types";

            StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    processHouseList(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    customDialog.stopLoading();
                    showSnackbar("Some Error Occurred");
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }
            };
            int socketTimeout = 90000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something went wrong.");
        }
    }

    private void processHouseList(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            String status = jsonObject.getString("status");
            ArrayList<String> spinner = new ArrayList<String>();
            spinner.add("--Select House Type--");
            house_type_hash.put("--Select House Type--", 0);
            if (status.equals("200")) {
                JSONArray list = jsonObject.getJSONArray("list");
                int len = list.length();
                for (int i = 0; i < len; i++) {
                    JSONObject objects = list.getJSONObject(i);
                    String id = objects.getString("id");
                    String name = objects.getString("title");
                    house_type_hash.put(name, Integer.parseInt(id));
                    spinner.add(name);
                }
                ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, spinner);
                spinner_house_type.setAdapter(spinnerAdapter);
            } else {
                showSnackbar("Error in Hosue List");
            }
            customDialog.stopLoading();
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something bad happened");
        }
    }

    private void UploadFormApi(JSONObject formdata) {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            String URL = Constants.API_URL + "apply-loan";

            SharedPreferences sharedPreferences = getContext().getSharedPreferences(USERDATA, MODE_PRIVATE);
            String api_token = sharedPreferences.getString("api_token", "");

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, URL, formdata, new com.android.volley.Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    formApiResponse(response);
                }
            }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Hide progressBar:
                    customDialog.stopLoading();
                    try {
                        String responseBody = new String(error.networkResponse.data, "utf-8");
                        JSONObject jsonObject = new JSONObject(responseBody);
                        if (jsonObject.has("errors")) {
                            String err = jsonObject.getString("errors");
                            showSnackbar(err);
                        } else {
                            showSnackbar("Some Error Occurred");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Authorization", "Bearer " + api_token);
                    return params;
                }
            };
            int socketTimeout = 180000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            jsonObjectRequest.setRetryPolicy(policy);
            requestQueue.add(jsonObjectRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    private void formApiResponse(JSONObject result) {
        String status;
        try {
            status = result.getString("status");
            if (status.equals("200")) {
                showSnackbar("Request submitted successfully");
                Intent intent = new Intent(getContext(), DashboardActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                String error = result.getString("errors");
                showSnackbar("Error" + error);
            }
            customDialog.stopLoading();
        } catch (Exception e) {
            // Hide progressBar:
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    public void showSnackbar(String msg) {
        Snackbar snackbar = Snackbar.make(view, "" + msg, Snackbar.LENGTH_LONG).setDuration(5000);
        snackbar.setTextColor(ContextCompat.getColor(getContext(), R.color.colorPrimaryDark));
        snackbar.setBackgroundTint(ContextCompat.getColor(getContext(), R.color.colorPrimary));
        snackbar.show();
    }
}