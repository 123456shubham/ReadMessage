package com.loanshala.loan_shala.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.loanshala.loan_shala.Others.Constants;
import com.loanshala.loan_shala.Others.CustomDialog;
import com.loanshala.loan_shala.Others.NetworkChecking;
import com.loanshala.loan_shala.R;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    TextInputEditText et_mobile;
    Button btn_login;
    TextView txt_forget, txt_signup;
    String mobile = "";
    CustomDialog customDialog;
    LinearLayout login_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login_layout = findViewById(R.id.login_layout);
        txt_signup = findViewById(R.id.txt_signup);
        et_mobile = findViewById(R.id.et_mobile);
        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);
        txt_signup.setOnClickListener(this);
        customDialog = new CustomDialog(LoginActivity.this);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login:
                try {
                    mobile = et_mobile.getText().toString().trim();
                    if (mobile.length() == 0) {
                        et_mobile.requestFocus();
                        et_mobile.setError("Mobile is Empty");
                    } else if (mobile.length() != 10) {
                        et_mobile.requestFocus();
                        et_mobile.setError("Enter Valid Mobile No");
                    } else {
                        NetworkChecking networkChecking = new NetworkChecking();
                        boolean network_status = networkChecking.internet_checking(getApplicationContext());
                        if (network_status) {
                            SendOtpApi();
                        } else {
                            showSnackbar("No Internet Connection!");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case R.id.txt_signup:
                Intent signup = new Intent(getApplicationContext(), SignupActivity.class);
                signup.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(signup);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                break;
        }
    }

    private void SendOtpApi() {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            String URL = Constants.API_URL + "send-otp";

            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    sendOtpResponse(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Hide progressBar:
                    customDialog.stopLoading();
                    showSnackbar("Some Error Occurred");
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }

                //Pass Your Parameters here
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("mobile", mobile);
                    return params;
                }
            };
            int socketTimeout = 90000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    private void sendOtpResponse(String result) {
        String status;
        try {
            JSONObject jsonObject1 = new JSONObject(result);
            status = jsonObject1.getString("status");
            if (status.equals("200")) {
                //Remove otp code after api implementation
                String otp = jsonObject1.getString("otp");
                Intent intent = new Intent(getApplicationContext(), OtpVerificationActivity.class);
                intent.putExtra("otp", otp);
                intent.putExtra("mobile", mobile);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            } else {
                String msg = jsonObject1.getString("msg");
                showSnackbar(msg);
            }
            customDialog.stopLoading();
        } catch (Exception e) {
            // Hide progressBar:
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    private void showSnackbar(String msg) {
        Snackbar snackbar = Snackbar.make(login_layout, "" + msg, Snackbar.LENGTH_LONG).setDuration(5000);
        snackbar.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimaryDark));
        snackbar.setBackgroundTint(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
        snackbar.show();
    }
}