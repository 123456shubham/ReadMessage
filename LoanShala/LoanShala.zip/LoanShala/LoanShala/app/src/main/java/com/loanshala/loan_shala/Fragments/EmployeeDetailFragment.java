package com.loanshala.loan_shala.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.loanshala.loan_shala.Others.CustomDialog;
import com.loanshala.loan_shala.R;

import java.util.HashMap;

public class EmployeeDetailFragment extends Fragment {
    View view;
    TextView form_name, txt_dob, file_chooser_gold_paper, file_chooser_gold_photo, file_chooser_property_paper, file_chooser_balance_sheet, file_chooser_car_bank_statement, file_chooser_car_paper, file_chooser_profile, file_chooser_cheque, file_chooser_other, file_chooser_verify_guarantor, file_chooser_verify_applicant, file_chooser_cibil, file_chooser_adhar_f, file_chooser_slip_2, file_chooser_statement, file_chooser_slip_3, file_chooser_slip_1, file_chooser_adhar_b, file_chooser_emp_id, file_chooser_pancard;
    String loan_type_name = "", time_format, file_param_name = "", loan_type = "", loan_amount = "", dob = "", staying_year = "", local_address = "", city = "";
    String mobile = "", email = "", fname = "", lname = "", pin = "", spouse_name = "", spouse_phone = "", spouse_occupation = "", current_loan = "", current_loan_emi = "", income = "", company_name = "", company_address = "";
    String working_year = "", banking_password = "", pan_no = "", aadhar_no = "";
    Spinner spinner_house_type, spinner_emp_type, spinner_salary_mode, spinner_state_type;
    Button home_btn_cancle, home_btn_save;
    RadioGroup gender_radio_group, marital_radio_group;
    RadioButton radiobutton;
    int index = 0, marital_status, gender, house_type, salary_mode, employement_type, state;
    EditText form_f_name, home_et_spouse_name, et_company_name, et_bank_pass, et_adhaar_no, et_pancard_nu, et_working_yr, et_company_add, home_et_curent_loan_amount, home_et_curent_loan_emi,
            et_salary, home_et_spouse_occupation, home_et_spouse_phone, form_l_name, home_et_form_email, home_et_local_add, home_et_pincode, home_et_state, home_et_city, home_et_form_mobile, home_et_staying_years;
    HashMap<Integer, TextView> idToTextviewHash;
    HashMap<String, String> base64Hash;
    private static final int SELECT_FILE = 2;
    private static final int MY_REQUEST_CODE_PERMISSION = 1000;
    CustomDialog customDialog;
    LinearLayout form_options, opt_personal_detail, upload_balance_sheet, upload_property_paper, upload_gold_paper, upload_gold_photo, upload_car_bank_statement, upload_car_paper;
    HashMap<String, Integer> state_code_hash;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_employee_detail, container, false);
        return view;
    }
}