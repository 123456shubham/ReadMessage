package com.loanshala.loan_shala.Others;

import android.app.Activity;
import android.app.AlertDialog;
import android.view.LayoutInflater;

import com.loanshala.loan_shala.R;

public class CustomDialog {
    Activity activity;
    AlertDialog dialog;

    public CustomDialog(Activity mActivity) {
        activity = mActivity;
    }

    public void startLoading() {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            LayoutInflater layoutInflater = activity.getLayoutInflater();
            builder.setView(layoutInflater.inflate(R.layout.custom_dialog_layout, null));
            builder.setCancelable(false);
            dialog = builder.create();
            dialog.show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void stopLoading() {
        try {
            dialog.dismiss();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
