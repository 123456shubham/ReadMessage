package com.loanshala.loan_shala.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.loanshala.loan_shala.R;

public class ForgetPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
    }
}