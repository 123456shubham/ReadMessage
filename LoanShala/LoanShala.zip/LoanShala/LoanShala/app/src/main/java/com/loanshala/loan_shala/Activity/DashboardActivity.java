package com.loanshala.loan_shala.Activity;

import static com.loanshala.loan_shala.Others.Constants.API_URL;
import static com.loanshala.loan_shala.Others.Constants.USERDATA;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.loanshala.loan_shala.Fragments.AboutFragment;
import com.loanshala.loan_shala.Fragments.HomeFragment;
import com.loanshala.loan_shala.Fragments.ProfileFragment;
import com.loanshala.loan_shala.Others.CustomDialog;
import com.loanshala.loan_shala.Others.CustomExpandableListAdapter;
import com.loanshala.loan_shala.Others.MenuModel;
import com.loanshala.loan_shala.Others.NetworkChecking;
import com.loanshala.loan_shala.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DashboardActivity extends AppCompatActivity {
    FrameLayout frameLayout;
    String user_id, api_token, mobile;
    NetworkChecking networkChecking;
    SharedPreferences sharedPreferences;
    DrawerLayout drawer;
    //Expandable List
    ExpandableListAdapter expandableListAdapter;
    ExpandableListView expandableListView;
    List<MenuModel> headerList = new ArrayList<>();
    HashMap<MenuModel, List<MenuModel>> childList = new HashMap<>();
    String[] menu = {"Home", "Profile", "Help"};
    boolean[] group = {true, true, true};
    boolean[] hasChildren = {false, false, false};
    HashMap<String, String[]> hash_map = new HashMap<>();
    CustomDialog customDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        frameLayout = findViewById(R.id.framelayout);
        customDialog = new CustomDialog(DashboardActivity.this);

        expandableListView = findViewById(R.id.expandableListView);

        prepareMenuData();
        populateExpandableList();

        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        FragmentTransaction fragmentTransaction2 = getSupportFragmentManager().beginTransaction();
        fragmentTransaction2.replace(R.id.framelayout, new HomeFragment());
        fragmentTransaction2.commit();
    }

    //Click on Navigation header
    public void headerOnClick(View view) {
        loadFragment(new AboutFragment());
        drawer.closeDrawer(GravityCompat.START);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dashboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_logout) {
            try {
                sharedPreferences = getSharedPreferences(USERDATA, MODE_PRIVATE);
                user_id = sharedPreferences.getString("user_id", "");
                mobile = sharedPreferences.getString("mobile", "");
                networkChecking = new NetworkChecking();
                boolean network_status = networkChecking.internet_checking(getApplicationContext());
                if (network_status) {
                    LogoutApi();
                } else {
                    showSnackbar("No Internet Connection!");
                }
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void prepareMenuData() {
        try {
            int len = menu.length;
            for (int i = 0; i < len; i++) {
                MenuModel menuModel = new MenuModel(menu[i], group[i], hasChildren[i], ""); //Menu of Home. No sub menus
                headerList.add(menuModel);
                if (!menuModel.hasChildren) {
                    childList.put(menuModel, null);
                } else {
                    String[] getValue, getlink;
                    List<MenuModel> childModelsList = new ArrayList<>();
                    String menu_name = menu[i];
                    getValue = hash_map.get(menu_name);
                    getlink = hash_map.get(menu_name + "_link");
                    int lenVal = getValue.length;
                    for (int j = 0; j < lenVal; j++) {
                        MenuModel childModel = new MenuModel(getValue[j], false, false, getlink[j]);
                        childModelsList.add(childModel);
                    }
                    if (menuModel.hasChildren) {
                        childList.put(menuModel, childModelsList);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void populateExpandableList() {
        expandableListAdapter = new CustomExpandableListAdapter(this, headerList, childList);
        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                if (headerList.get(groupPosition).isGroup) {
                    if (!headerList.get(groupPosition).hasChildren) {
                        switch (groupPosition) {
                            case 0:
                                loadFragment(new HomeFragment());
                                break;
                            case 1:
                                loadFragment(new ProfileFragment());
                                break;
                            case 2:
                                loadFragment(new AboutFragment());
                                break;
                        }
                        onBackPressed();
                    }
                }
                return false;
            }
        });
    }

    private void LogoutApi() {
        try {
            customDialog.startLoading();
            sharedPreferences = getSharedPreferences(USERDATA, MODE_PRIVATE);
            api_token = sharedPreferences.getString("api_token", "");
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            String URL = API_URL + "logout";

            StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    afterLogoutTask(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    customDialog.stopLoading();
                    showSnackbar("Some Error Occurred");
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    params.put("Authorization", "Bearer " + api_token);
                    return params;
                }
            };
            int socketTimeout = 90000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something went wrong.");
        }
    }

    private void afterLogoutTask(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            String status = jsonObject.getString("status");
            if (status.equals("200")) {
                SharedPreferences sharedPreferences = getSharedPreferences(USERDATA, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.apply();
                Intent intent = new Intent(getApplicationContext(), LauncherScreenActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            } else {
                showSnackbar("Error");
            }
            customDialog.stopLoading();
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something bad happened");
        }
    }

    public void loadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.framelayout, fragment);
        fragmentTransaction.addToBackStack("DashboardActivity");
        fragmentTransaction.commit();
    }

    public void showSnackbar(String msg) {
        Snackbar snackbar = Snackbar.make(frameLayout, "" + msg, Snackbar.LENGTH_LONG).setDuration(5000);
        snackbar.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimaryDark));
        snackbar.setBackgroundTint(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
        snackbar.show();
    }
}