package com.loanshala.loan_shala.Activity;

import static com.loanshala.loan_shala.Others.Constants.API_URL;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.loanshala.loan_shala.Others.CustomDialog;
import com.loanshala.loan_shala.Others.NetworkChecking;
import com.loanshala.loan_shala.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignupActivity extends AppCompatActivity {
    TextInputEditText et_first_name, et_email, et_mobile, et_last_name;
    Button btn_register;
    TextView txt_login, errorText;
    LinearLayout errorTextLayout;
    String first_name = "", last_name = "", email = "", contact = "";
    CustomDialog customDialog;
    ScrollView layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        layout = findViewById(R.id.signup_scrollview);
        et_first_name = findViewById(R.id.et_first_name);
        et_email = findViewById(R.id.et_email);
        et_mobile = findViewById(R.id.et_mobile);
        et_last_name = findViewById(R.id.et_last_name);
        txt_login = findViewById(R.id.txt_login);
        btn_register = findViewById(R.id.btn_register);
        customDialog = new CustomDialog(SignupActivity.this);
        try {
            btn_register.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    first_name = et_first_name.getText().toString();
                    email = et_email.getText().toString();
                    contact = et_mobile.getText().toString();
                    last_name = et_last_name.getText().toString();
                    if (first_name.length() == 0) {
                        et_first_name.requestFocus();
                        et_first_name.setError("First Name is Empty");
                    } else if (!first_name.matches("[a-zA-Z][a-zA-Z]*")/*!name.matches("[a-zA-Z][a-zA-Z ]+[a-zA-Z]$+") || !name.matches("[a-zA-Z]+[a-zA-Z]$+")*/) {
                        et_first_name.requestFocus();
                        et_first_name.setError("ENTER ONLY ALPHABETICAL CHARACTER");
                    } else if (last_name.length() == 0) {
                        et_last_name.requestFocus();
                        et_last_name.setError("Last Name is Empty");
                    } else if (!last_name.matches("[a-zA-Z][a-zA-Z]*")/*!name.matches("[a-zA-Z][a-zA-Z ]+[a-zA-Z]$+") || !name.matches("[a-zA-Z]+[a-zA-Z]$+")*/) {
                        et_last_name.requestFocus();
                        et_last_name.setError("ENTER ONLY ALPHABETICAL CHARACTER");
                    } else if (email.length() == 0) {
                        et_email.requestFocus();
                        et_email.setError("Email Id is Empty");
                    } else if (!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")) {
                        et_email.requestFocus();
                        et_email.setError("Enter Valid Email Id");
                    } else if (contact.length() == 0) {
                        et_mobile.requestFocus();
                        et_mobile.setError("Mobile is Empty");
                    } else if (contact.length() != 10) {
                        et_mobile.requestFocus();
                        et_mobile.setError("Enter Valid Mobile No");
                    } else {
                        NetworkChecking networkChecking = new NetworkChecking();
                        boolean network_status = networkChecking.internet_checking(getApplicationContext());
                        if (network_status) {
                            SignupTask();
                        } else {
                            showSnackbar("No Internet Connection!");
                        }
                    }
                }
            });

            txt_login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    finish();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SignupTask() {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            String URL = API_URL + "signup";

            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    saveData(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Hide progressBar:
                    customDialog.stopLoading();
                    showSnackbar("Failed To Create Account!!");

                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }

                //Pass Your Parameters here
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("first_name", first_name);
                    params.put("email", email);
                    params.put("mobile", contact);
                    params.put("last_name", last_name);
                    return params;
                }
            };
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something went wrong");
        }
    }

    private void saveData(String result) {
        String status;
        try {
            JSONObject jsonObject = new JSONObject(result);
            status = jsonObject.getString("status");
            if (status.equals("200")) {
                showSnackbar("Account Created. Go to Login Now.");
                et_first_name.setText("");
                et_email.setText("");
                et_mobile.setText("");
                et_last_name.setText("");
            } else {
                showSnackbar("Error");
            }
            customDialog.stopLoading();
        } catch (JSONException e) {
            customDialog.stopLoading();
            showSnackbar("Something bad happened");
        }
    }

    public void showSnackbar(String msg) {
        Snackbar snackbar = Snackbar.make(layout, "" + msg, Snackbar.LENGTH_LONG).setDuration(5000);
        snackbar.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimaryDark));
        snackbar.setBackgroundTint(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
        snackbar.show();
    }
}