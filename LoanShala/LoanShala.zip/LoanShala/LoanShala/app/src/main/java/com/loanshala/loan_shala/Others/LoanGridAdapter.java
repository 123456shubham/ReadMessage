package com.loanshala.loan_shala.Others;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.loanshala.loan_shala.R;

import java.util.ArrayList;

public class LoanGridAdapter extends ArrayAdapter<LoanGridModel> implements AdapterView.OnItemClickListener{
    public LoanGridAdapter(@NonNull Context context, ArrayList<LoanGridModel> loanGridModelArrayList) {
        super(context, 0, loanGridModelArrayList);
    }

    @NonNull
    @Override
    public View getView(int position, @NonNull View converView, @NonNull ViewGroup parent) {
        View listView = converView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.loan_type_layout_card, parent, false);
        }
        LoanGridModel loanGridModel = getItem(position);
        TextView textView = listView.findViewById(R.id.txt_type);
        ImageView imageView = listView.findViewById(R.id.img_type);
        textView.setText(loanGridModel.getLoanType());
        imageView.setImageResource(loanGridModel.getTypeImgId());
        return listView;
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }
}
