package com.loanshala.loan_shala.Activity;

import static com.loanshala.loan_shala.Others.Constants.USERDATA;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.loanshala.loan_shala.Others.Constants;
import com.loanshala.loan_shala.Others.CustomDialog;
import com.loanshala.loan_shala.Others.NetworkChecking;
import com.loanshala.loan_shala.R;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class OtpVerificationActivity extends AppCompatActivity {
    TextInputEditText et_otp;
    Button btn_verify;
    String otp = "", mobile = "";
    CustomDialog customDialog;
    LinearLayout login_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);
        login_layout = findViewById(R.id.login_layout);
        et_otp = findViewById(R.id.et_otp);
        btn_verify = findViewById(R.id.btn_verify);
//remove otp code after ApI implementation
        String otp_value = getIntent().getStringExtra("otp");
        mobile = getIntent().getStringExtra("mobile");
        et_otp.setText(otp_value);
        btn_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    otp = et_otp.getText().toString().trim();
                    if (otp.length() == 0) {
                        et_otp.requestFocus();
                        et_otp.setError("Please enter OTP");
                    } else {
                        NetworkChecking networkChecking = new NetworkChecking();
                        boolean network_status = networkChecking.internet_checking(getApplicationContext());
                        if (network_status) {
                            VerifyOtpApi();
                        } else {
                            showSnackbar("No Internet Connection!");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        customDialog = new CustomDialog(OtpVerificationActivity.this);
    }

    private void VerifyOtpApi() {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            String URL = Constants.API_URL + "verify-otp";

            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    verifyApiResponse(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Hide progressBar:
                    customDialog.stopLoading();
                    showSnackbar("Some Error Occurred");
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }

                //Pass Your Parameters here
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("otp", otp);
                    params.put("mobile", mobile);
                    return params;
                }
            };
            int socketTimeout = 90000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    private void verifyApiResponse(String result) {
        String user_name, status, api_token, user_data, user_email, user_id, user_mobile, is_app_user, parent_id, user_type, user_otp, app_infra = "", setting_key = "", setting_value = "", app_license, crm_popup_type, crm_type, repeat_index = "0", app_outbound_process = "1", app_outbound_number = "", crm_form_id = "";
        try {
            JSONObject jsonObject1 = new JSONObject(result);
            status = jsonObject1.getString("status");
            if (status.equals("200")) {
                api_token = jsonObject1.getString("token");
                user_data = jsonObject1.getString("user");
                if (!user_data.equals("")) {
                    try {
                        JSONObject jsonObject = new JSONObject(user_data.trim());
                        user_id = jsonObject.getString("id");
                        user_name = jsonObject.getString("name");
                        user_email = jsonObject.getString("email");
                        user_mobile = jsonObject.getString("mobile");
                        is_app_user = jsonObject.getString("is_app_user");

                        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(USERDATA, MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("user_id", user_id);
                        editor.putString("user_name", user_name);
                        editor.putString("user_email", user_email);
                        editor.putString("user_mobile", user_mobile);
                        editor.putString("is_app_user", is_app_user);
                        editor.putString("api_token", api_token);
                        editor.putBoolean("isLoggedIn", true);

                        editor.apply();

                        Intent intent = new Intent(getApplicationContext(), DashboardActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        finish();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                showSnackbar("Error");
            }
            customDialog.stopLoading();
        } catch (Exception e) {
            // Hide progressBar:
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    private void showSnackbar(String msg) {
        Snackbar snackbar = Snackbar.make(login_layout, "" + msg, Snackbar.LENGTH_LONG).setDuration(5000);
        snackbar.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimaryDark));
        snackbar.setBackgroundTint(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
        snackbar.show();
    }
}