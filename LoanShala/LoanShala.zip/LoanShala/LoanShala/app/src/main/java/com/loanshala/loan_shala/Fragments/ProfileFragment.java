package com.loanshala.loan_shala.Fragments;

import static android.content.Context.MODE_PRIVATE;

import static com.loanshala.loan_shala.Others.Constants.USERDATA;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.loanshala.loan_shala.Activity.DashboardActivity;
import com.loanshala.loan_shala.Activity.OtpVerificationActivity;
import com.loanshala.loan_shala.Others.Constants;
import com.loanshala.loan_shala.Others.CustomDialog;
import com.loanshala.loan_shala.R;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProfileFragment extends Fragment {
    View view;
    TextView name, mobileNumber, emailId;
    CustomDialog customDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_profile, container, false);
        getActivity().setTitle("Profile");
        name = view.findViewById(R.id.name);
        mobileNumber = view.findViewById(R.id.mobileNumber);
        emailId = view.findViewById(R.id.emailId);
        customDialog = new CustomDialog(getActivity());
        GetProfileApi();
        return view;
    }

    private void GetProfileApi() {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            String URL = Constants.API_URL + "profile";

            SharedPreferences sharedPreferences = getContext().getSharedPreferences(USERDATA, MODE_PRIVATE);
            String api_token = sharedPreferences.getString("api_token", "");

            StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    profileApiResponse(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Hide progressBar:
                    customDialog.stopLoading();
                    showSnackbar("Some Error Occurred");
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    params.put("Authorization", "Bearer " + api_token);
                    return params;
                }
            };
            int socketTimeout = 90000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    private void profileApiResponse(String result) {
        String user_name, status, user_data, user_email, user_mobile;
        try {
            JSONObject jsonObject1 = new JSONObject(result);
            status = jsonObject1.getString("message");
            if (status.equals("Success.")) {
                user_data = jsonObject1.getString("user");
                if (!user_data.equals("")) {
                    try {
                        JSONObject jsonObject = new JSONObject(user_data.trim());
                        user_name = jsonObject.getString("name");
                        user_email = jsonObject.getString("email");
                        user_mobile = jsonObject.getString("mobile");
                        name.setText(user_name);
                        mobileNumber.setText(user_mobile);
                        emailId.setText(user_email);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                showSnackbar("Error");
            }
            customDialog.stopLoading();
        } catch (Exception e) {
            // Hide progressBar:
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    public void showSnackbar(String msg) {
        Snackbar snackbar = Snackbar.make(view, "" + msg, Snackbar.LENGTH_LONG).setDuration(5000);
        snackbar.setTextColor(ContextCompat.getColor(getContext(), R.color.colorPrimaryDark));
        snackbar.setBackgroundTint(ContextCompat.getColor(getContext(), R.color.colorPrimary));
        snackbar.show();
    }
}