package com.loanshala.loan_shala.Fragments;

import static android.content.Context.MODE_PRIVATE;
import static com.loanshala.loan_shala.Others.Constants.API_URL;
import static com.loanshala.loan_shala.Others.Constants.USERDATA;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.loanshala.loan_shala.Activity.LauncherScreenActivity;
import com.loanshala.loan_shala.Others.Constants;
import com.loanshala.loan_shala.Others.CustomDialog;
import com.loanshala.loan_shala.Others.LoanGridAdapter;
import com.loanshala.loan_shala.Others.LoanGridModel;
import com.loanshala.loan_shala.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class HomeFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    View view;
    GridView loan_type_grid;
    CardView loan_form_card;
    TextView form_name, txt_dob, file_chooser_gold_paper, file_chooser_gold_photo, file_chooser_property_paper, file_chooser_balance_sheet, file_chooser_car_bank_statement, file_chooser_car_paper, file_chooser_profile, file_chooser_cheque, file_chooser_other, file_chooser_verify_guarantor, file_chooser_verify_applicant, file_chooser_cibil, file_chooser_adhar_f, file_chooser_slip_2, file_chooser_statement, file_chooser_slip_3, file_chooser_slip_1, file_chooser_adhar_b, file_chooser_emp_id, file_chooser_pancard;
    String loan_type_name = "", time_format, file_param_name = "", loan_type = "", loan_amount = "", dob = "", staying_year = "", local_address = "", city = "";
    String mobile = "", email = "", fname = "", lname = "", pin = "", spouse_name = "", spouse_phone = "", spouse_occupation = "", current_loan = "", current_loan_emi = "", income = "", company_name = "", company_address = "";
    String working_year = "", banking_password = "", pan_no = "", aadhar_no = "";
    Spinner spinner_house_type, spinner_emp_type, spinner_salary_mode, spinner_state_type;
    Button home_btn_cancle, home_btn_save;
    RadioGroup gender_radio_group, marital_radio_group;
    RadioButton radiobutton;
    int index = 0, marital_status, gender, house_type, salary_mode, employement_type, state;
    EditText form_f_name, home_et_spouse_name, et_company_name, et_bank_pass, et_adhaar_no, et_pancard_nu, et_working_yr, et_company_add, home_et_curent_loan_amount, home_et_curent_loan_emi,
            et_salary, home_et_spouse_occupation, home_et_spouse_phone, form_l_name, home_et_form_email, home_et_local_add, home_et_pincode, home_et_state, home_et_city, home_et_form_mobile, home_et_staying_years;
    HashMap<Integer, TextView> idToTextviewHash;
    HashMap<String, String> base64Hash;
    private static final int SELECT_FILE = 2;
    private static final int MY_REQUEST_CODE_PERMISSION = 1000;
    CustomDialog customDialog;
    LinearLayout form_options, opt_personal_detail, upload_balance_sheet, upload_property_paper, upload_gold_paper, upload_gold_photo, upload_car_bank_statement, upload_car_paper;
    HashMap<String, Integer> state_code_hash;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_home, container, false);
        getActivity().setTitle("Dashboard");
        loan_type_grid = view.findViewById(R.id.loan_type_grid);
        loan_form_card = view.findViewById(R.id.loan_form_card);
        form_name = view.findViewById(R.id.form_name);
        form_options = view.findViewById(R.id.form_options);
        opt_personal_detail = view.findViewById(R.id.opt_personal_detail);
        opt_personal_detail.setOnClickListener(this);


        txt_dob = view.findViewById(R.id.txt_dob);
        form_f_name = view.findViewById(R.id.form_f_name);
        home_et_spouse_name = view.findViewById(R.id.home_et_spouse_name);
        et_company_name = view.findViewById(R.id.et_company_name);
        et_bank_pass = view.findViewById(R.id.et_bank_pass);
        et_adhaar_no = view.findViewById(R.id.et_adhaar_no);
        et_pancard_nu = view.findViewById(R.id.et_pancard_nu);
        et_working_yr = view.findViewById(R.id.et_working_yr);
        et_company_add = view.findViewById(R.id.et_company_add);
        home_et_curent_loan_amount = view.findViewById(R.id.home_et_curent_loan_amount);
        home_et_curent_loan_emi = view.findViewById(R.id.home_et_curent_loan_emi);
        et_salary = view.findViewById(R.id.et_salary);
        home_et_spouse_occupation = view.findViewById(R.id.home_et_spouse_occupation);
        home_et_spouse_phone = view.findViewById(R.id.home_et_spouse_phone);
        form_l_name = view.findViewById(R.id.form_l_name);
        home_et_form_email = view.findViewById(R.id.home_et_form_email);
        home_et_local_add = view.findViewById(R.id.home_et_local_add);
        home_et_pincode = view.findViewById(R.id.home_et_pincode);
        home_et_city = view.findViewById(R.id.home_et_city);
        home_et_form_mobile = view.findViewById(R.id.home_et_form_mobile);
        home_et_staying_years = view.findViewById(R.id.home_et_staying_years);
        gender_radio_group = view.findViewById(R.id.gender_radio_group);
        marital_radio_group = view.findViewById(R.id.marital_radio_group);

        spinner_emp_type = view.findViewById(R.id.spinner_emp_type);
        spinner_house_type = view.findViewById(R.id.spinner_house_type);
        spinner_salary_mode = view.findViewById(R.id.spinner_salary_mode);
        spinner_state_type = view.findViewById(R.id.spinner_state_type);
        spinner_salary_mode.setOnItemSelectedListener(this);
        spinner_house_type.setOnItemSelectedListener(this);
        spinner_salary_mode.setOnItemSelectedListener(this);
        spinner_state_type.setOnItemSelectedListener(this);

        home_btn_cancle = view.findViewById(R.id.home_btn_cancle);
        home_btn_save = view.findViewById(R.id.home_btn_save);

        upload_balance_sheet = view.findViewById(R.id.upload_balance_sheet);
        upload_property_paper = view.findViewById(R.id.upload_property_paper);
        upload_gold_paper = view.findViewById(R.id.upload_gold_paper);
        upload_gold_photo = view.findViewById(R.id.upload_gold_photo);
        upload_car_bank_statement = view.findViewById(R.id.upload_car_bank_statement);
        upload_car_paper = view.findViewById(R.id.upload_car_paper);

        file_chooser_profile = view.findViewById(R.id.file_chooser_profile);
        file_chooser_emp_id = view.findViewById(R.id.file_chooser_emp_id);
        file_chooser_pancard = view.findViewById(R.id.file_chooser_pancard);
        file_chooser_adhar_f = view.findViewById(R.id.file_chooser_adhar_f);
        file_chooser_adhar_b = view.findViewById(R.id.file_chooser_adhar_b);
        file_chooser_slip_1 = view.findViewById(R.id.file_chooser_slip_1);
        file_chooser_slip_2 = view.findViewById(R.id.file_chooser_slip_2);
        file_chooser_slip_3 = view.findViewById(R.id.file_chooser_slip_3);
        file_chooser_statement = view.findViewById(R.id.file_chooser_statement);
        file_chooser_cheque = view.findViewById(R.id.file_chooser_cheque);
        file_chooser_cibil = view.findViewById(R.id.file_chooser_cibil);
        file_chooser_other = view.findViewById(R.id.file_chooser_other);
        file_chooser_verify_applicant = view.findViewById(R.id.file_chooser_verify_applicant);
        file_chooser_verify_guarantor = view.findViewById(R.id.file_chooser_verify_guarantor);
        file_chooser_balance_sheet = view.findViewById(R.id.file_chooser_balance_sheet);
        file_chooser_car_paper = view.findViewById(R.id.file_chooser_car_paper);
        file_chooser_gold_photo = view.findViewById(R.id.file_chooser_gold_photo);
        file_chooser_car_bank_statement = view.findViewById(R.id.file_chooser_car_bank_statement);
        file_chooser_property_paper = view.findViewById(R.id.file_chooser_property_paper);
        file_chooser_gold_paper = view.findViewById(R.id.file_chooser_gold_paper);

        //Store all textviews for file chooser
        idToTextviewHash = new HashMap<>();
        idToTextviewHash.put(R.id.file_chooser_profile, file_chooser_profile);
        idToTextviewHash.put(R.id.file_chooser_emp_id, file_chooser_emp_id);
        idToTextviewHash.put(R.id.file_chooser_pancard, file_chooser_pancard);
        idToTextviewHash.put(R.id.file_chooser_adhar_f, file_chooser_adhar_f);
        idToTextviewHash.put(R.id.file_chooser_adhar_b, file_chooser_adhar_b);
        idToTextviewHash.put(R.id.file_chooser_slip_1, file_chooser_slip_1);
        idToTextviewHash.put(R.id.file_chooser_slip_2, file_chooser_slip_2);
        idToTextviewHash.put(R.id.file_chooser_slip_3, file_chooser_slip_3);
        idToTextviewHash.put(R.id.file_chooser_statement, file_chooser_statement);
        idToTextviewHash.put(R.id.file_chooser_cheque, file_chooser_cheque);
        idToTextviewHash.put(R.id.file_chooser_cibil, file_chooser_cibil);
        idToTextviewHash.put(R.id.file_chooser_other, file_chooser_other);
        idToTextviewHash.put(R.id.file_chooser_verify_applicant, file_chooser_verify_applicant);
        idToTextviewHash.put(R.id.file_chooser_verify_guarantor, file_chooser_verify_guarantor);
        idToTextviewHash.put(R.id.file_chooser_balance_sheet, file_chooser_balance_sheet);
        idToTextviewHash.put(R.id.file_chooser_gold_photo, file_chooser_gold_photo);
        idToTextviewHash.put(R.id.file_chooser_car_bank_statement, file_chooser_car_bank_statement);
        idToTextviewHash.put(R.id.file_chooser_property_paper, file_chooser_property_paper);
        idToTextviewHash.put(R.id.file_chooser_gold_paper, file_chooser_gold_paper);
        idToTextviewHash.put(R.id.file_chooser_car_paper, file_chooser_car_paper);

        txt_dob.setOnClickListener(this);
        home_btn_cancle.setOnClickListener(this);
        home_btn_save.setOnClickListener(this);

        file_chooser_profile.setOnClickListener(this);
        file_chooser_emp_id.setOnClickListener(this);
        file_chooser_pancard.setOnClickListener(this);
        file_chooser_adhar_f.setOnClickListener(this);
        file_chooser_adhar_b.setOnClickListener(this);
        file_chooser_slip_1.setOnClickListener(this);
        file_chooser_slip_2.setOnClickListener(this);
        file_chooser_slip_3.setOnClickListener(this);
        file_chooser_statement.setOnClickListener(this);
        file_chooser_cheque.setOnClickListener(this);
        file_chooser_cibil.setOnClickListener(this);
        file_chooser_other.setOnClickListener(this);
        file_chooser_verify_applicant.setOnClickListener(this);
        file_chooser_verify_guarantor.setOnClickListener(this);
        file_chooser_balance_sheet.setOnClickListener(this);
        file_chooser_car_paper.setOnClickListener(this);
        file_chooser_car_bank_statement.setOnClickListener(this);
        file_chooser_property_paper.setOnClickListener(this);
        file_chooser_gold_paper.setOnClickListener(this);
        file_chooser_gold_photo.setOnClickListener(this);

        ArrayList<LoanGridModel> loanModelArrayList = new ArrayList<LoanGridModel>();
        loanModelArrayList.add(new LoanGridModel("Personal loan", R.drawable.ic_personal_loan, "1"));
        loanModelArrayList.add(new LoanGridModel("Business Loan", R.drawable.ic_business_loan, "2"));
        loanModelArrayList.add(new LoanGridModel("Loan Against property", R.drawable.ic_property_loan, "3"));
        loanModelArrayList.add(new LoanGridModel("Gold Loan", R.drawable.ic_gold_loan, "4"));
        loanModelArrayList.add(new LoanGridModel("Home Loan", R.drawable.ic_home_loan, "5"));
        loanModelArrayList.add(new LoanGridModel("Car Loan", R.drawable.ic_car_loan, "6"));

        //Create hash map with all base64 default values
        base64Hash = new HashMap<>();
        base64Hash.put("image", "");
        base64Hash.put("employee_id", "");
        base64Hash.put("pan_front_photo", "");
        base64Hash.put("aadhar_front_photo", "");
        base64Hash.put("aadhar_back_photo", "");
        base64Hash.put("salary_slip_1", "");
        base64Hash.put("salary_slip_2", "");
        base64Hash.put("salary_slip_3", "");
        base64Hash.put("bank_statement", "");
        base64Hash.put("cheque_upload", "");
        base64Hash.put("cibil", "");
        base64Hash.put("other_documents", "");
        base64Hash.put("verify_applicant", "");
        base64Hash.put("verify_gurantor", "");
        base64Hash.put("balance_sheet", "");
        base64Hash.put("car_paper", "");
        base64Hash.put("car_bank_statement", "");
        base64Hash.put("property_paper", "");
        base64Hash.put("gold_paper", "");
        base64Hash.put("gold_photo", "");

        state_code_hash = new HashMap<>();
        customDialog = new CustomDialog(getActivity());

        LoanGridAdapter adapter = new LoanGridAdapter(getContext(), loanModelArrayList);
        loan_type_grid.setAdapter(adapter);
        loan_type_grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                LoanGridModel lm = loanModelArrayList.get(i);
                loan_type_grid.setVisibility(View.GONE);
                form_options.setVisibility(View.VISIBLE);
                loan_type_name = lm.getLoanType();
                loan_type = lm.getLoanTypeId();
//                loan_form_card.setVisibility(View.VISIBLE);
//                loan_type_grid.setVisibility(View.GONE);
//                form_name.setText(lm.getLoanType() + " ");
//                loan_type = lm.getLoanTypeId();
//                //Business Loan
//                if (loan_type.equals("2")) {
//                    upload_balance_sheet.setVisibility(View.VISIBLE);
//                }
//                //Loan Against Property
//                if (loan_type.equals("3")) {
//                    upload_property_paper.setVisibility(View.VISIBLE);
//                }
//                //Gold Loan
//                if (loan_type.equals("4")) {
//                    upload_gold_paper.setVisibility(View.VISIBLE);
//                    upload_gold_photo.setVisibility(View.VISIBLE);
//                }
//                //Car Loan
//                if (loan_type.equals("6")) {
//                    upload_car_bank_statement.setVisibility(View.VISIBLE);
//                    upload_car_paper.setVisibility(View.VISIBLE);
//                }
//
//                getStateList();
//
//                //House Type
//                ArrayList<String> spinnerArray = new ArrayList<String>();
//                spinnerArray.add("--Select House Type--");
//                spinnerArray.add("Own");
//                spinnerArray.add("Parents");
//                ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, spinnerArray);
//                spinner_house_type.setAdapter(spinnerArrayAdapter);
//
//                //Employment Type
//                ArrayList<String> spinnerEmp = new ArrayList<String>();
//                spinnerEmp.add("--Select Employment Type--");
//                spinnerEmp.add("Private");
//                spinnerEmp.add("LLP");
//                ArrayAdapter<String> spinnerEmpAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, spinnerEmp);
//                spinner_emp_type.setAdapter(spinnerEmpAdapter);
//
//                //Salary Mode
//                ArrayList<String> spinnerSal = new ArrayList<String>();
//                spinnerSal.add("--Select Salary Mode--");
//                spinnerSal.add("Bank");
//                spinnerSal.add("Cash");
//                ArrayAdapter<String> spinnerSalAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, spinnerSal);
//                spinner_salary_mode.setAdapter(spinnerSalAdapter);
            }
        });

        gender_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                radiobutton = (RadioButton) group.findViewById(checkedId);
                if (checkedId != 0) {
                    String selected = (String) radiobutton.getText();
                    if (selected.equals("Male")) {
                        gender = 1;
                    } else if (selected.equals("Female")) {
                        gender = 2;
                    } else {
                        gender = 3;
                    }
                }
            }
        });
        marital_radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                radiobutton = (RadioButton) group.findViewById(checkedId);
                if (checkedId != 0) {
                    String selected = (String) radiobutton.getText();
                    if (selected.equals("Married")) {
                        marital_status = 1;
                    } else {
                        marital_status = 0;
                    }
                }
            }
        });

        return view;
    }

    public void date(final TextView textView) {
        final int mYear, mMonth, mDay;
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        time_format = dateFormat.format(c.getInstance().getTime());
        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), R.style.MyDatePickerDialogTheme,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        monthOfYear += 1;
                        String month, day;   //local variable
                        if (monthOfYear < 10) {
                            month = "0" + monthOfYear;
                        }//if month less than 10 then add 0 before month
                        else {
                            month = String.valueOf(monthOfYear);
                        }
                        if (dayOfMonth < 10) {
                            day = "0" + dayOfMonth;
                        }//if day less than 10 then add 0 before day
                        else {
                            day = String.valueOf(dayOfMonth);
                        }
                        String date = day + "-" + month + "-" + year;
                        textView.setText(date);
                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    public void showSnackbar(String msg) {
        Snackbar snackbar = Snackbar.make(view, "" + msg, Snackbar.LENGTH_LONG).setDuration(5000);
        snackbar.setTextColor(ContextCompat.getColor(getContext(), R.color.colorPrimaryDark));
        snackbar.setBackgroundTint(ContextCompat.getColor(getContext(), R.color.colorPrimary));
        snackbar.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (parent.getId() == R.id.spinner_emp_type) {
            employement_type = position;
        }
        if (parent.getId() == R.id.spinner_salary_mode) {
            salary_mode = position;
        }
        if (parent.getId() == R.id.spinner_house_type) {
            house_type = position;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        try {
            switch (view.getId()) {
                case R.id.txt_dob:
                    date(txt_dob);
                    break;

                case R.id.opt_personal_detail:
                    loadFragment(new PersonalDetailFragment());
                    break;
                //Combined case for file choosers.
                case R.id.file_chooser_emp_id:
                    index = view.getId();
                    file_param_name = "employee_id";
                    askPermission();
                    break;
                case R.id.file_chooser_profile:
                    index = view.getId();
                    file_param_name = "image";
                    askPermission();
                    break;
                case R.id.file_chooser_adhar_b:
                    index = view.getId();
                    file_param_name = "aadhar_back_photo";
                    askPermission();
                    break;
                case R.id.file_chooser_adhar_f:
                    index = view.getId();
                    file_param_name = "aadhar_front_photo";
                    askPermission();
                    break;
                case R.id.file_chooser_pancard:
                    index = view.getId();
                    file_param_name = "pan_front_photo";
                    askPermission();
                    break;
                case R.id.file_chooser_slip_1:
                    index = view.getId();
                    file_param_name = "salary_slip_1";
                    askPermission();
                    break;
                case R.id.file_chooser_slip_2:
                    index = view.getId();
                    file_param_name = "salary_slip_2";
                    askPermission();
                    break;
                case R.id.file_chooser_slip_3:
                    index = view.getId();
                    file_param_name = "salary_slip_3";
                    askPermission();
                    break;
                case R.id.file_chooser_statement:
                    index = view.getId();
                    file_param_name = "bank_statement";
                    askPermission();
                    break;
                case R.id.file_chooser_cheque:
                    index = view.getId();
                    file_param_name = "cheque_upload";
                    askPermission();
                    break;
                case R.id.file_chooser_cibil:
                    index = view.getId();
                    file_param_name = "cibil";
                    askPermission();
                    break;
                case R.id.file_chooser_other:
                    index = view.getId();
                    file_param_name = "other_documents";
                    askPermission();
                    break;
                case R.id.file_chooser_verify_applicant:
                    index = view.getId();
                    file_param_name = "verify_applicant";
                    askPermission();
                    break;
                case R.id.file_chooser_verify_guarantor:
                    index = view.getId();
                    file_param_name = "verify_gurantor";
                    askPermission();
                    break;
                case R.id.file_chooser_balance_sheet:
                    index = view.getId();
                    file_param_name = "balance_sheet";
                    askPermission();
                    break;
                case R.id.file_chooser_car_paper:
                    index = view.getId();
                    file_param_name = "car_paper";
                    askPermission();
                    break;
                case R.id.file_chooser_car_bank_statement:
                    index = view.getId();
                    file_param_name = "car_bank_statement";
                    askPermission();
                    break;
                case R.id.file_chooser_property_paper:
                    index = view.getId();
                    file_param_name = "property_paper";
                    askPermission();
                    break;
                case R.id.file_chooser_gold_paper:
                    index = view.getId();
                    file_param_name = "gold_paper";
                    askPermission();
                    break;
                case R.id.file_chooser_gold_photo:
                    index = view.getId();
                    file_param_name = "gold_photo";
                    askPermission();
                    break;
                case R.id.home_btn_save:
                    loan_amount = home_et_curent_loan_amount.getText().toString();
                    if (loan_amount.equals("") || loan_amount.equals("0")) {
                        home_et_curent_loan_amount.requestFocus();
                        home_et_curent_loan_amount.setError("Please Enter amount");
                    } else {
                        fname = form_f_name.getText().toString();
                        lname = form_l_name.getText().toString();
                        email = home_et_form_email.getText().toString();
                        mobile = home_et_form_mobile.getText().toString();
                        dob = txt_dob.getText().toString();
                        staying_year = home_et_staying_years.getText().toString();
                        local_address = home_et_local_add.getText().toString();
                        city = home_et_city.getText().toString();
                        pin = home_et_pincode.getText().toString();
                        spouse_name = home_et_spouse_name.getText().toString();
                        spouse_phone = home_et_spouse_phone.getText().toString();
                        spouse_occupation = home_et_spouse_occupation.getText().toString();
                        current_loan = home_et_curent_loan_amount.getText().toString();
                        current_loan_emi = home_et_curent_loan_emi.getText().toString();
                        income = et_salary.getText().toString();
                        company_name = et_company_name.getText().toString();
                        company_address = et_company_add.getText().toString();
                        working_year = et_working_yr.getText().toString();
                        banking_password = et_bank_pass.getText().toString();
                        pan_no = et_pancard_nu.getText().toString();
                        aadhar_no = et_adhaar_no.getText().toString();
                        state = state_code_hash.get(spinner_state_type.getSelectedItem().toString());
//                employement_type = spinner_emp_type.getSelectedItem().toString();
//                house_type = spinner_house_type.getSelectedItem().toString();
//                salary_mode = spinner_salary_mode.getSelectedItem().toString();

                        JSONObject params = new JSONObject();
                        try {
                            params.put("loan_type", loan_type);
                            params.put("loan_amount", loan_amount);
                            if (gender >= 0) {
                                params.put("gender", gender);
                            }
                            if (!dob.equals("")) {
                                params.put("dob", dob);
                            }
                            if (house_type > 0) {
                                params.put("house_type", house_type);
                            }
                            if (!staying_year.equals("")) {
                                params.put("staying_year", staying_year);
                            }
                            if (!local_address.equals("")) {
                                params.put("local_address", local_address);
                            }
                            if (state > 0) {
                                params.put("state", state);
                            }
                            if (!city.equals("")) {
                                params.put("city", city);
                            }
                            if (!pin.equals("")) {
                                params.put("pin", pin);
                            }
                            if (marital_status >= 0) {
                                params.put("marital_status", marital_status);
                            }
                            if (!spouse_name.equals("")) {
                                params.put("spouse_name", spouse_name);
                            }
                            if (!spouse_phone.equals("")) {
                                params.put("spouse_phone", spouse_phone);
                            }
                            if (!spouse_occupation.equals("")) {
                                params.put("spouse_occupation", spouse_occupation);
                            }
                            if (!current_loan.equals("")) {
                                params.put("current_loan", current_loan);
                            }
                            if (!current_loan_emi.equals("")) {
                                params.put("current_loan_emi", current_loan_emi);
                            }
                            if (!income.equals("")) {
                                params.put("income", income);
                            }
                            if (!spouse_phone.equals("")) {
                                params.put("spouse_phone", spouse_phone);
                            }
                            if (!company_name.equals("")) {
                                params.put("company_name", company_name);
                            }
                            if (!company_address.equals("")) {
                                params.put("company_address", company_address);
                            }
                            if (employement_type > 0) {
                                params.put("employement_type", employement_type);
                            }
                            if (salary_mode > 0) {
                                params.put("salary_mode", salary_mode);
                            }
                            if (!working_year.equals("")) {
                                params.put("working_year", working_year);
                            }
                            if (!banking_password.equals("")) {
                                params.put("banking_password", banking_password);
                            }
                            if (!pan_no.equals("")) {
                                params.put("pan_no", pan_no);
                            }
                            if (!aadhar_no.equals("")) {
                                params.put("aadhar_no", aadhar_no);
                            }
                            if (!base64Hash.get("image").equals("")) {
                                params.put("image", "data:image/jpeg;base64," + base64Hash.get("image"));
                            }
                            if (!base64Hash.get("employee_id").equals("")) {
                                params.put("employee_id", "data:image/jpeg;base64," + base64Hash.get("employee_id"));
                            }
                            if (!base64Hash.get("pan_front_photo").equals("")) {
                                params.put("pan_front_photo", "data:image/jpeg;base64," + base64Hash.get("pan_front_photo"));
                            }
                            if (!base64Hash.get("aadhar_front_photo").equals("")) {
                                params.put("aadhar_front_photo", "data:image/jpeg;base64," + base64Hash.get("aadhar_front_photo"));
                            }
                            if (!base64Hash.get("aadhar_back_photo").equals("")) {
                                params.put("aadhar_back_photo", "data:image/jpeg;base64," + base64Hash.get("aadhar_back_photo"));
                            }
                            if (!base64Hash.get("salary_slip_1").equals("")) {
                                params.put("salary_slip_1", "data:image/jpeg;base64," + base64Hash.get("salary_slip_1"));
                            }
                            if (!base64Hash.get("salary_slip_2").equals("")) {
                                params.put("salary_slip_2", "data:image/jpeg;base64," + base64Hash.get("salary_slip_2"));
                            }
                            if (!base64Hash.get("salary_slip_3").equals("")) {
                                params.put("salary_slip_3", "data:image/jpeg;base64," + base64Hash.get("salary_slip_3"));
                            }
                            if (!base64Hash.get("bank_statement").equals("")) {
                                params.put("bank_statement", "data:image/jpeg;base64," + base64Hash.get("bank_statement"));
                            }
                            if (!base64Hash.get("cheque_upload").equals("")) {
                                params.put("cheque_upload", "data:image/jpeg;base64," + base64Hash.get("cheque_upload"));
                            }
                            if (!base64Hash.get("cibil").equals("")) {
                                params.put("cibil", "data:image/jpeg;base64," + base64Hash.get("cibil"));
                            }
                            if (!base64Hash.get("other_documents").equals("")) {
                                params.put("other_documents", "data:image/jpeg;base64," + base64Hash.get("other_documents"));
                            }
                            if (!base64Hash.get("verify_applicant").equals("")) {
                                params.put("verify_applicant", "data:image/jpeg;base64," + base64Hash.get("verify_applicant"));
                            }
                            if (!base64Hash.get("verify_gurantor").equals("")) {
                                params.put("verify_gurantor", "data:image/jpeg;base64," + base64Hash.get("verify_gurantor"));
                            }
                            //Business Loan
                            if (loan_type.equals("2") && !base64Hash.get("balance_sheet").equals("")) {
                                params.put("balance_sheet", "data:image/jpeg;base64," + base64Hash.get("balance_sheet"));
                            }
                            //Car loan
                            if (loan_type.equals("6")) {
                                if (!base64Hash.get("car_paper").equals("")) {
                                    params.put("car_paper", "data:image/jpeg;base64," + base64Hash.get("car_paper"));
                                }
                                if (!base64Hash.get("car_bank_statement").equals("")) {
                                    params.put("car_bank_statement", "data:image/jpeg;base64," + base64Hash.get("car_bank_statement"));
                                }
                            }
                            //Loan Against property
                            if (loan_type.equals("3") && !base64Hash.get("property_paper").equals("")) {
                                params.put("property_paper", "data:image/jpeg;base64," + base64Hash.get("property_paper"));
                            }
                            //Gold Loan
                            if (loan_type.equals("4")) {
                                if (!base64Hash.get("gold_paper").equals("")) {
                                    params.put("gold_paper", "data:image/jpeg;base64," + base64Hash.get("gold_paper"));
                                }
                                if (!base64Hash.get("gold_photo").equals("")) {
                                    params.put("gold_photo", "data:image/jpeg;base64," + base64Hash.get("gold_photo"));
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }


//                else if (mobile.equals("") || mobile.length() != 10) {
//                    home_et_form_mobile.requestFocus();
//                    home_et_form_mobile.setError("Please Enter mobile");
//                }

                        UploadFormApi(params);
                    }
                    break;
                case R.id.home_btn_cancle:
                    resetLayout();
                    loan_form_card.setVisibility(View.GONE);
                    loan_type_grid.setVisibility(View.VISIBLE);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            showSnackbar("Some Internal Error Occurred");
        }
    }

    private void resetLayout() {
        loan_form_card.setVisibility(View.GONE);
        loan_type_grid.setVisibility(View.VISIBLE);

        upload_balance_sheet.setVisibility(View.GONE);
        upload_property_paper.setVisibility(View.GONE);
        upload_gold_paper.setVisibility(View.GONE);
        upload_gold_photo.setVisibility(View.GONE);
        upload_car_bank_statement.setVisibility(View.GONE);
        upload_car_paper.setVisibility(View.GONE);
    }

    private void askPermission() {
        // With Android Level >= 23, you have to ask the user
        // for permission to access External Storage.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) { // Level 23

            // Check if we have Call permission
            int permisson = ActivityCompat.checkSelfPermission(getContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE);

            if (permisson != PackageManager.PERMISSION_GRANTED) {
                // If don't have permission so prompt the user.
                this.requestPermissions(
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_REQUEST_CODE_PERMISSION
                );
                return;
            }
        }
        openGallery();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //
        if (requestCode == MY_REQUEST_CODE_PERMISSION) {// Note: If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openGallery();
            }
            // Cancelled or denied.
            else {
                showSnackbar("Permission Denied");
            }
        }
    }

    private void openGallery() {
        Intent chooseFileIntent = new Intent(Intent.ACTION_PICK);
        chooseFileIntent.setType("image/*");
        // Only return URIs that can be opened with ContentResolver
//        chooseFileIntent.addCategory(Intent.CATEGORY_OPENABLE);
        chooseFileIntent = Intent.createChooser(chooseFileIntent, "Choose a file");
        startActivityForResult(chooseFileIntent, SELECT_FILE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == getActivity().RESULT_OK) {
            if (requestCode == SELECT_FILE) {
                System.out.println("SELECT_FILE");
                Uri selectedImageUri = data.getData();
                getPath(selectedImageUri);
            }
        }
    }

    public void getPath(Uri uri) {
        try {
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContext().getContentResolver().query(uri, projection, null, null, null);
            if (cursor.getCount() > 0) {
                if (cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndex(projection[0]);
                    String filepath = cursor.getString(columnIndex);
                    Uri url = Uri.parse(filepath);
                    File file = new File(url.getPath());

                    float length = file.length();
                    if (length >= 50000000) {
                        showSnackbar("Media too long. Max allowed size : 5MB");
                    } else {
                        byte[] ByteArray = new byte[(int) file.length()];
                        try {
                            FileInputStream fileInputStream = new FileInputStream(file);
                            fileInputStream.read(ByteArray);
                            byte[] encodeFile = Base64.encode(ByteArray, 0);
                            String sfile = new String(encodeFile);
                            base64Hash.put(file_param_name, sfile);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        String filename = file.getName();
                        idToTextviewHash.get(index).setText(filename);
                        showSnackbar("Selected File : " + filename);
                    }
                }
                cursor.close();
            } else {
                showSnackbar("No file selected");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showSnackbar("Something went wrong");
        }
    }

    private void getStateList() {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            String URL = API_URL + "states";

            StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    afterLogoutTask(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    customDialog.stopLoading();
                    showSnackbar("Some Error Occurred");
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }
            };
            int socketTimeout = 90000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something went wrong.");
        }
    }

    private void afterLogoutTask(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            String status = jsonObject.getString("status");
            ArrayList<String> spinnerState = new ArrayList<String>();
            spinnerState.add("--Select State--");
            state_code_hash.put("--Select State--", 0);
            if (status.equals("200")) {
                JSONArray list = jsonObject.getJSONArray("list");
                int len = list.length();
                for (int i = 0; i < len; i++) {
                    JSONObject objects = list.getJSONObject(i);
                    String state_id = objects.getString("StateID");
                    String state_name = objects.getString("StateName");
                    state_code_hash.put(state_name, Integer.parseInt(state_id));
                    spinnerState.add(state_name);
                }
                ArrayAdapter<String> spinnerStateAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, spinnerState);
                spinner_state_type.setAdapter(spinnerStateAdapter);
            } else {
                showSnackbar("Error");
            }
            customDialog.stopLoading();
        } catch (Exception e) {
            customDialog.stopLoading();
            showSnackbar("Something bad happened");
        }
    }

    private void UploadFormApi(JSONObject formdata) {
        try {
            customDialog.startLoading();
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            String URL = Constants.API_URL + "apply-loan";

            SharedPreferences sharedPreferences = getContext().getSharedPreferences(USERDATA, MODE_PRIVATE);
            String api_token = sharedPreferences.getString("api_token", "");

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, URL, formdata, new com.android.volley.Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    formApiResponse(response);
                }
            }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Hide progressBar:
                    customDialog.stopLoading();
                    try {
                        String responseBody = new String(error.networkResponse.data, "utf-8");
                        JSONObject jsonObject = new JSONObject(responseBody);
                        if (jsonObject.has("errors")) {
                            String err = jsonObject.getString("errors");
                            showSnackbar(err);
                        } else {
                            showSnackbar("Some Error Occurred");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Authorization", "Bearer " + api_token);
                    return params;
                }
            };
            int socketTimeout = 180000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            jsonObjectRequest.setRetryPolicy(policy);
            requestQueue.add(jsonObjectRequest);
        } catch (Exception e) {
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    private void formApiResponse(JSONObject result) {
        String status;
        try {
            status = result.getString("status");
            if (status.equals("200")) {
                showSnackbar("Request submitted successfully");
                resetLayout();
            } else {
                String error = result.getString("errors");
                showSnackbar("Error" + error);
            }
            customDialog.stopLoading();
        } catch (Exception e) {
            // Hide progressBar:
            customDialog.stopLoading();
            e.printStackTrace();
        }
    }

    public void loadFragment(Fragment fragment) {
        Bundle bundle = new Bundle();
        bundle.putString("loan_name", loan_type_name);
        bundle.putString("loan_id", loan_type);
        FragmentManager fragmentManager = getFragmentManager();
        fragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.framelayout, fragment);
        fragmentTransaction.addToBackStack("DashboardActivity");
        fragmentTransaction.commit();
    }
}