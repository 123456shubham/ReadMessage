package com.unt.hci.fantasycricket;

/**
 * Created by Manoj Kumar on 3/21/2017.
 * edited by deepak
 */

public class testscore {
    int i;
    int j;
}
