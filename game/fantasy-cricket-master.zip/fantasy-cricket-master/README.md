# fantasy-cricket
Android application to simulate fantasy cricket using data from previous tournaments.
